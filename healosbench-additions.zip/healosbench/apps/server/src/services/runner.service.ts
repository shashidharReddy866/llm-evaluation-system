/**
 * apps/server/src/services/runner.service.ts
 *
 * Orchestrates evaluation runs:
 *   - 5-slot semaphore for concurrency control
 *   - SSE event pub/sub so the route layer can stream to clients
 *   - Idempotent case storage (same transcript_id + strategy + model → cached)
 *   - Resumable: POST /api/v1/runs/:id/resume skips already-completed cases
 *   - 429 exponential backoff is handled inside packages/llm (not here)
 */

import { db } from "@healosbench/db";
import { extractService } from "./extract.service";
import { evaluateService } from "./evaluate.service";
import { loadDataset } from "./dataset.service";
import type { RunConfig, RunEvent } from "@healosbench/shared";

// ---------------------------------------------------------------------------
// Semaphore — caps concurrent Anthropic calls at 5
// ---------------------------------------------------------------------------
class Semaphore {
  private slots: number;
  private queue: Array<() => void> = [];

  constructor(slots: number) {
    this.slots = slots;
  }

  async acquire(): Promise<void> {
    if (this.slots > 0) {
      this.slots--;
      return;
    }
    return new Promise((resolve) => this.queue.push(resolve));
  }

  release(): void {
    const next = this.queue.shift();
    if (next) {
      next();
    } else {
      this.slots++;
    }
  }
}

const sem = new Semaphore(5);

// ---------------------------------------------------------------------------
// Pub/sub — lets SSE route subscribe to per-run events
// ---------------------------------------------------------------------------
type Subscriber = (event: RunEvent) => void | Promise<void>;
const subscribers = new Map<string, Set<Subscriber>>();

function publish(runId: string, event: RunEvent): void {
  const subs = subscribers.get(runId);
  if (!subs) return;
  for (const sub of subs) {
    Promise.resolve(sub(event)).catch(console.error);
  }
}

// ---------------------------------------------------------------------------
// Runner service
// ---------------------------------------------------------------------------
export const runnerService = {
  /**
   * Subscribe to SSE events for a given runId.
   * Returns an unsubscribe function.
   */
  subscribe(runId: string, cb: Subscriber): () => void {
    if (!subscribers.has(runId)) subscribers.set(runId, new Set());
    subscribers.get(runId)!.add(cb);
    return () => subscribers.get(runId)?.delete(cb);
  },

  /**
   * Create the run row in the DB (status = "pending").
   * The caller should then call startRun(id) separately so SSE can attach first.
   */
  async createRun(config: RunConfig) {
    const run = await db.createRun(config);
    return run;
  },

  /**
   * Start processing all cases for a run.
   * Called by the SSE handler after subscribing.
   */
  async startRun(runId: string): Promise<void> {
    const run = await db.getRun(runId);
    if (!run) throw new Error(`Run ${runId} not found`);

    await db.updateRunStatus(runId, "running");

    const dataset = await loadDataset(run.datasetFilter ?? undefined);
    const completedIds = new Set(
      (await db.getCasesForRun(runId))
        .filter((c) => c.status === "completed")
        .map((c) => c.transcriptId)
    );

    const pending = dataset.filter((t) => !completedIds.has(t.id));

    // Process cases concurrently (semaphore limits to 5 in-flight)
    await Promise.allSettled(
      pending.map((transcript) =>
        this._processCase(runId, run.strategy, run.model, transcript)
      )
    );

    // Aggregate final scores
    const allCases = await db.getCasesForRun(runId);
    const completedCases = allCases.filter((c) => c.status === "completed");

    const aggregateF1 =
      completedCases.length > 0
        ? completedCases.reduce((acc, c) => {
            const scores = Object.values(c.scores ?? {}) as number[];
            return acc + (scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0);
          }, 0) / completedCases.length
        : 0;

    const totalTokens = allCases.reduce((acc, c) => acc + (c.totalTokens ?? 0), 0);
    const totalCost = allCases.reduce((acc, c) => acc + (c.costUsd ?? 0), 0);
    const wallTimeMs = Date.now() - new Date(run.createdAt).getTime();

    await db.completeRun(runId, { aggregateF1, totalTokens, totalCost, wallTimeMs });

    publish(runId, { type: "run_complete", aggregateF1, totalCost, totalTokens, wallTimeMs });
  },

  /**
   * Resume a run that was interrupted. Skips already-completed cases.
   */
  async resumeRun(runId: string): Promise<void> {
    await db.updateRunStatus(runId, "running");
    // Kick off in background (SSE caller can re-subscribe to :id/stream)
    this.startRun(runId).catch(console.error);
  },

  // -------------------------------------------------------------------------
  // Internal: process a single transcript case
  // -------------------------------------------------------------------------
  async _processCase(
    runId: string,
    strategy: string,
    model: string,
    transcript: { id: string; text: string; gold: Record<string, unknown> }
  ): Promise<void> {
    await sem.acquire();
    try {
      // Idempotency check — don't re-call LLM if already stored
      const existing = await db.getCaseResult(runId, transcript.id);
      if (existing?.status === "completed") {
        publish(runId, {
          type: "case_complete",
          transcriptId: transcript.id,
          scores: existing.scores,
          attempt: existing.attempts,
          cached: true,
        });
        return;
      }

      // Extract
      const extraction = await extractService.extract(
        transcript.text,
        strategy,
        model
      );

      // Evaluate
      const evaluation = evaluateService.evaluate(
        transcript.text,
        extraction.result,
        transcript.gold as any
      );

      // Persist
      await db.saveCaseResult(runId, transcript.id, {
        status: "completed",
        prediction: extraction.result,
        scores: evaluation.scores,
        hallucinationCount: evaluation.hallucinationCount,
        schemaFailures: extraction.schemaFailures,
        attempts: extraction.attempts,
        totalTokens: extraction.usage.inputTokens + extraction.usage.outputTokens,
        cacheReadTokens: extraction.usage.cacheReadTokens,
        cacheWriteTokens: extraction.usage.cacheWriteTokens,
        costUsd: extraction.costUsd,
        trace: extraction.trace,
      });

      publish(runId, {
        type: "case_complete",
        transcriptId: transcript.id,
        scores: evaluation.scores,
        attempt: extraction.attempts,
        cached: false,
        hallucinationCount: evaluation.hallucinationCount,
      });
    } catch (err) {
      await db.saveCaseResult(runId, transcript.id, {
        status: "failed",
        error: String(err),
      });

      publish(runId, {
        type: "case_error",
        transcriptId: transcript.id,
        error: String(err),
      });
    } finally {
      sem.release();
    }
  },
};
