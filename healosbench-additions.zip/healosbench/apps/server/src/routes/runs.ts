/**
 * apps/server/src/routes/runs.ts
 *
 * Hono route handlers for run management with SSE progress streaming.
 * Replace / merge with your existing runs router.
 */

import { Hono } from "hono";
import { stream } from "hono/streaming";
import { runnerService } from "../services/runner.service";
import { db } from "@healosbench/db";

const runs = new Hono();

/**
 * POST /api/v1/runs
 * Start a new evaluation run.
 * Body: { strategy: "zero_shot"|"few_shot"|"cot", model: string, dataset_filter?: string, force?: boolean }
 */
runs.post("/", async (c) => {
  const body = await c.req.json();
  const { strategy, model, dataset_filter, force } = body;

  if (!strategy || !model) {
    return c.json({ error: "strategy and model are required" }, 400);
  }

  const run = await runnerService.createRun({ strategy, model, dataset_filter, force });
  return c.json({ runId: run.id }, 201);
});

/**
 * GET /api/v1/runs/:id/stream
 * SSE endpoint — streams progress events as cases complete.
 *
 * Event format (newline-delimited):
 *   data: {"type":"case_complete","transcriptId":"01","scores":{...},"attempt":1}
 *   data: {"type":"run_complete","aggregateF1":0.87,"totalCost":0.0042}
 *   data: {"type":"error","message":"..."}
 */
runs.get("/:id/stream", async (c) => {
  const runId = c.req.param("id");

  // Verify run exists
  const run = await db.getRun(runId);
  if (!run) return c.json({ error: "Run not found" }, 404);

  c.header("Content-Type", "text/event-stream");
  c.header("Cache-Control", "no-cache");
  c.header("Connection", "keep-alive");
  c.header("X-Accel-Buffering", "no"); // disable nginx buffering

  return stream(c, async (stream) => {
    const send = async (payload: object) => {
      await stream.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    // If run is already complete, replay stored results and close
    if (run.status === "completed" || run.status === "failed") {
      const cases = await db.getCasesForRun(runId);
      for (const cas of cases) {
        await send({
          type: "case_complete",
          transcriptId: cas.transcriptId,
          scores: cas.scores,
          attempt: cas.attempts,
          cached: true,
        });
      }
      await send({ type: "run_complete", aggregateF1: run.aggregateF1, totalCost: run.totalCost });
      return;
    }

    // Subscribe to live events from the runner
    const unsubscribe = runnerService.subscribe(runId, async (event) => {
      await send(event);
    });

    // Start the run if not already running
    runnerService.startRun(runId).catch(async (err) => {
      await send({ type: "error", message: String(err) });
    });

    // Keep stream alive with periodic comments until run ends
    const keepAlive = setInterval(async () => {
      await stream.write(": ping\n\n");
    }, 15_000);

    // Wait for run completion signal
    await new Promise<void>((resolve) => {
      const cleanup = runnerService.subscribe(runId, (event) => {
        if (event.type === "run_complete" || event.type === "error") {
          cleanup();
          resolve();
        }
      });
    });

    clearInterval(keepAlive);
    unsubscribe();
  });
});

/**
 * POST /api/v1/runs/:id/resume
 * Resume a crashed or incomplete run from the last completed case.
 */
runs.post("/:id/resume", async (c) => {
  const runId = c.req.param("id");
  const run = await db.getRun(runId);
  if (!run) return c.json({ error: "Run not found" }, 404);
  if (run.status === "completed") return c.json({ message: "Run already completed" });

  await runnerService.resumeRun(runId);
  return c.json({ message: "Run resumed", runId });
});

/**
 * GET /api/v1/runs
 * List all runs with summary metadata.
 */
runs.get("/", async (c) => {
  const allRuns = await db.listRuns();
  return c.json({ runs: allRuns });
});

/**
 * GET /api/v1/runs/:id
 * Full run detail: meta + per-case scores + field averages + LLM traces.
 */
runs.get("/:id", async (c) => {
  const runId = c.req.param("id");
  const run = await db.getRun(runId);
  if (!run) return c.json({ error: "Run not found" }, 404);

  const cases = await db.getCasesForRun(runId);

  // Compute per-field averages across all completed cases
  const fields = ["chief_complaint", "vitals", "medications", "diagnoses", "plan", "follow_up"] as const;
  const fieldAverages = Object.fromEntries(
    fields.map((f) => {
      const vals = cases.map((c) => c.scores?.[f] ?? 0).filter((v) => v != null);
      return [f, vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0];
    })
  );

  const hallucinationCount = cases.reduce((acc, c) => acc + (c.hallucinationCount ?? 0), 0);
  const schemaFailureCount = cases.reduce((acc, c) => acc + (c.schemaFailures ?? 0), 0);
  const cacheReadTokens = cases.reduce((acc, c) => acc + (c.cacheReadTokens ?? 0), 0);

  return c.json({
    meta: run,
    cases,
    fieldAverages,
    hallucinationCount,
    schemaFailureCount,
    cacheReadTokens,
  });
});

export { runs as runsRouter };
